prompt --application/shared_components/logic/application_processes/delete_conversation
begin
--   Manifest
--     APPLICATION PROCESS: Delete Conversation
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.5'
,p_default_workspace_id=>8913349955741052
,p_default_application_id=>101
,p_default_id_offset=>8914865186760203
,p_default_owner=>'MOVIESTREAM'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(122153371604472788)
,p_process_sequence=>1
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Delete Conversation'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DELETE FROM ADB_CHAT_CONVERSATIONS WHERE ID = :P1_CONV_ID;',
':P1_CONV_ID := NULL;'))
,p_process_clob_language=>'PLSQL'
,p_process_when=>'DELETE_CONVERSATION'
,p_process_when_type=>'REQUEST_EQUALS_CONDITION'
,p_version_scn=>44299283727363
);
wwv_flow_imp.component_end;
end;
/
