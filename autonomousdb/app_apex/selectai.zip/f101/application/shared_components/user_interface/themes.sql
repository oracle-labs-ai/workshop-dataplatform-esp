prompt --application/shared_components/user_interface/themes
begin
--   Manifest
--     THEME: 101
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.5'
,p_default_workspace_id=>8913349955741052
,p_default_application_id=>101
,p_default_id_offset=>8914865186760203
,p_default_owner=>'MOVIESTREAM'
);
wwv_flow_imp_shared.create_theme(
 p_id=>wwv_flow_imp.id(49875650423864905382)
,p_theme_id=>42
,p_theme_name=>'Universal Theme'
,p_theme_internal_name=>'UNIVERSAL_THEME'
,p_version_identifier=>'23.2'
,p_navigation_type=>'L'
,p_nav_bar_type=>'LIST'
,p_reference_id=>4070917134413059350
,p_is_locked=>false
,p_current_theme_style_id=>wwv_flow_imp.id(119612829285526873)
,p_default_page_template=>wwv_flow_imp.id(49875015454959905275)
,p_default_dialog_template=>wwv_flow_imp.id(49875010312364905273)
,p_error_template=>wwv_flow_imp.id(49875000228467905270)
,p_printer_friendly_template=>wwv_flow_imp.id(49875015454959905275)
,p_breadcrumb_display_point=>'REGION_POSITION_01'
,p_sidebar_display_point=>'REGION_POSITION_02'
,p_login_template=>wwv_flow_imp.id(49875000228467905270)
,p_default_button_template=>wwv_flow_imp.id(49875565454227905338)
,p_default_region_template=>wwv_flow_imp.id(49875492193245905307)
,p_default_chart_template=>wwv_flow_imp.id(49875492193245905307)
,p_default_form_template=>wwv_flow_imp.id(49875492193245905307)
,p_default_reportr_template=>wwv_flow_imp.id(49875492193245905307)
,p_default_tabform_template=>wwv_flow_imp.id(49875492193245905307)
,p_default_wizard_template=>wwv_flow_imp.id(49875492193245905307)
,p_default_menur_template=>wwv_flow_imp.id(49875504558473905312)
,p_default_listr_template=>wwv_flow_imp.id(49875492193245905307)
,p_default_irr_template=>wwv_flow_imp.id(49875482361924905303)
,p_default_report_template=>wwv_flow_imp.id(49875530493057905322)
,p_default_label_template=>wwv_flow_imp.id(49875562926188905337)
,p_default_menu_template=>wwv_flow_imp.id(49875567090173905339)
,p_default_calendar_template=>wwv_flow_imp.id(49875567152961905339)
,p_default_list_template=>wwv_flow_imp.id(49875546895057905329)
,p_default_nav_list_template=>wwv_flow_imp.id(49875558713988905335)
,p_default_top_nav_list_temp=>wwv_flow_imp.id(49875558713988905335)
,p_default_side_nav_list_temp=>wwv_flow_imp.id(49875553266365905332)
,p_default_nav_list_position=>'SIDE'
,p_default_dialogbtnr_template=>wwv_flow_imp.id(49875028351458905281)
,p_default_dialogr_template=>wwv_flow_imp.id(49875025529997905280)
,p_default_option_label=>wwv_flow_imp.id(49875562926188905337)
,p_default_required_label=>wwv_flow_imp.id(49875564233242905337)
,p_default_navbar_list_template=>wwv_flow_imp.id(49875552830646905332)
,p_file_prefix => nvl(wwv_flow_application_install.get_static_theme_file_prefix(42),'#APEX_FILES#themes/theme_42/23.2/')
,p_files_version=>64
,p_icon_library=>'FONTAPEX'
,p_javascript_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#APEX_FILES#libraries/apex/#MIN_DIRECTORY#widget.stickyWidget#MIN#.js?v=#APEX_VERSION#',
'#THEME_FILES#js/theme42#MIN#.js?v=#APEX_VERSION#'))
,p_css_file_urls=>'#THEME_FILES#css/Core#MIN#.css?v=#APEX_VERSION#'
);
wwv_flow_imp.component_end;
end;
/
